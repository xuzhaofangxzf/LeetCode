﻿// Sort.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include "insertSort.h"
#include "SortTestHelper.h"
#include "quickSort.h"
#include "mergeSort.h"
int main()
{
	const int n = 20;
	int* arr = SortTestHelper::generateRandomArray(n, 10, 50);
	SortTestHelper::printArray(arr, n);
	cout << "=======================================================================" << endl;
	mergeSort(arr, n);
	//SortTestHelper::printArray(arr, n);

	//SortTestHelper::testSort("partition Sort", mergeSort, arr, n);
	if (SortTestHelper::isSorted(arr, n))
	{
		cout << "Arr is Sorted!" << endl;
	}
	else
	{
		cout << "Arr is unSorted!" << endl;

	}
	SortTestHelper::printArray(arr, n);
}
